//
//  ListCell.swift
//  CRUD
//
//  Created by SOTSYS027 on 09/02/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import UIKit

class ListCell: UITableViewCell {
    
    // MARK: - Outlets
    @IBOutlet weak var LabelFname: UILabel!
    @IBOutlet weak var LabelLname: UILabel!
    @IBOutlet weak var LabelDept: UILabel!
    
    var cellData = [String:String](){
        didSet{
            LabelFname.text = cellData["fname"]
            LabelLname.text = cellData["lname"]
            LabelDept.text = cellData["dept"]
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
