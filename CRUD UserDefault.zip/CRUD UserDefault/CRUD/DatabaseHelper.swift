//
//  DatabaseHelper.swift
//  CRUD
//
//  Created by SOTSYS027 on 09/02/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import Foundation
class DatabaseHelper{
    static let sharedInstance = DatabaseHelper()
    var defaults = UserDefaults.standard
    func save(dataPass:[String:String]){
        var saveArraData = getAllData()
        saveArraData.append(dataPass)
        defaults.setValue(saveArraData, forKey: "SaveData")
        defaults.synchronize()
        print(saveArraData)
    }
    func edit(dataPass:[String:String], index:Int){
        var array = getAllData()
        array[index] = dataPass
        defaults.setValue(array, forKey: "SaveData")
    }
    func clear(){
        defaults.removeObject(forKey: "SaveData")
    }
    func getAllData() -> [[String:String]]{
        if defaults.value(forKey: "SaveData") == nil{
            var array = [[String:String]]()
            return array
        }
        return defaults.array(forKey: "SaveData") as! [[String : String]]
    }
}

