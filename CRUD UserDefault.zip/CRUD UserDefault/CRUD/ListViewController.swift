//
//  ListViewController.swift
//  CRUD
//
//  Created by SOTSYS027 on 09/02/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import UIKit

protocol dataProtocol {
   // func dataPass(object:[String:String], index:Int, )
    func dataPass(object:[String:String],index:Int, bool:Bool)
}

class ListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    // MARK: - Outlets
    @IBOutlet weak var tableView: UITableView!
    var arrData = [[String:String]]()
    var delegate:dataProtocol?
    
    // MARK: - LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        arrData = DatabaseHelper.sharedInstance.getAllData()
        self.tableView.tableFooterView = UIView()
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    // MARK: - TableView Delegate & Datasource Methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ListCell", for: indexPath) as! ListCell
        cell.cellData = arrData[indexPath.row]
        return cell
    }

    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
          arrData.remove(at: indexPath.row)
          UserDefaults.standard.setValue(arrData, forKey: "SaveData")
          tableView.deleteRows(at: [indexPath], with: .automatic)
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let data = ["fname":arrData[indexPath.row]["fname"]!,"lname":arrData[indexPath.row]["lname"]!,"dept":arrData[indexPath.row]["dept"]!]
        print(data)
        delegate?.dataPass(object: data,index: indexPath.row, bool: true)
        print(data)
        self.navigationController?.popViewController(animated: true)
    }
}
