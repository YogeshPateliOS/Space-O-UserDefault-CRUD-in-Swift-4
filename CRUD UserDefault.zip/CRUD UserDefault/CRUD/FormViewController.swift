//
//  FormViewController.swift
//  CRUD
//
//  Created by SOTSYS027 on 09/02/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import UIKit

class FormViewController: UIViewController, dataProtocol  {
    
    // MARK: - Outlets
    static let sharedInstance = FormViewController()
    var setIndex = Int()
    var isUpdate = false
    @IBOutlet weak var fnameTextField: UITextField!
    @IBOutlet weak var lnameTextField: UITextField!
    @IBOutlet weak var deptTextField: UITextField!
    @IBOutlet weak var outSave: UIButton!
    
    // MARK: - LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewDidDisappear(_ animated: Bool) {
        clear()
    }
    
    // MARK: - Actions
    @IBAction func btnSave(_ sender: UIButton) {
        if fnameTextField.text == ""{
            alert(title: "", message: "Please Enter First Name", delegate: self)
        }else if lnameTextField.text == ""{
            alert(title: "", message: "Please Enter Last Name", delegate: self)
        }else if deptTextField.text == ""{
            alert(title: "", message: "Please Enter Department", delegate: self)
        }else{
            var dict = [String:String]()
            dict = ["fname":fnameTextField.text!,"lname":lnameTextField.text!,"dept":deptTextField.text!]
            if isUpdate == true{
                DatabaseHelper.sharedInstance.edit(dataPass: dict,index: setIndex)
                clear()
                isUpdate = false
                outSave.setTitle("Save", for: .normal)
            }else{
                DatabaseHelper.sharedInstance.save(dataPass: dict)
                clear()
        }
    }
}
    
    @IBAction func btnClear(_ sender: UIButton) {
        DatabaseHelper.sharedInstance.clear()
    }
    
    @IBAction func btnShow(_ sender: UIButton) {
        let listViewController = self.storyboard?.instantiateViewController(withIdentifier: "ListViewController") as! ListViewController
        listViewController.delegate = self
        DatabaseHelper.sharedInstance.getAllData()
        self.navigationController?.pushViewController(listViewController, animated: true)
    }
    
    // MARK: - Methods
    func dataPass(object: [String : String],index: Int, bool: Bool) {
      fnameTextField.text = object["fname"]
      lnameTextField.text = object["lname"]
      deptTextField.text = object["dept"]
      outSave.setTitle("Update", for: .normal)
      setIndex = index
      isUpdate = bool
    }

    func alert(title:String, message:String, delegate:AnyObject){
        let alertView = UIAlertView()
        alertView.title = title
        alertView.message = message
        alertView.delegate = self
        alertView.addButton(withTitle: "OK")
        alertView.show()
    }
    func clear(){
        fnameTextField.text = ""
        lnameTextField.text = ""
        deptTextField.text = ""
    }
}
